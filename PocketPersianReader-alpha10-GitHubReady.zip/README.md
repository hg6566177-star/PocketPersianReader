# Pocket Persian Reader Alpha 8

This is an Android source project ZIP, not a compiled APK.

Alpha 8:
- Save the reading chunk index persistently when stopping, advancing, or completing playback.
- Restore the saved chunk position when tapping Continue, including after app restart (assuming the saved text remains).
- TXT file import, text auto-save, speed slider and Android system TTS remain.

The project calls Android's system TTS API with the Persian locale. It does not bundle its own Persian voice or the sherpa-onnx runtime/model. Install a compatible Persian TTS voice/engine on Android, then select it in Android's Text-to-Speech settings. A sherpa-onnx Persian engine/model may be one option, but it has not been integrated or tested in this app.

APK build workflow:
1. Push the project folder to a GitHub repository.
2. Open Actions and run the "Build Android APK" workflow.
3. Download the `PocketPersianReader-debug-apk` artifact.

Build/device testing has not yet been completed in this environment.

Alpha 9 also resets saved reading progress when the user edits the text, and uses the standard Android TTS settings action. Build guide: BUILD_APK_FA.md.

Alpha 10: clarified repository-root upload and APK build steps in Persian. Build remains unverified; this archive does not include an APK.
