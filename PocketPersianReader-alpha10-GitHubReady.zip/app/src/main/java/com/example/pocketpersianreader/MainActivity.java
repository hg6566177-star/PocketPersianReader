package com.example.pocketpersianreader;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.Gravity;
import android.widget.*;
import android.graphics.Typeface;
import android.text.TextWatcher;
import android.text.Editable;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;

/** Alpha5: persistent text/settings and chunk-progress feedback; Android TTS fallback. */
public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    EditText textBox; TextView status; TextToSpeech systemTts; SeekBar speed;
    Button play, stop, resume, next; boolean ttsReady=false; static final int PICK_TEXT=10;
    List<String> chunks=new ArrayList<>(); int activeChunk=0; boolean speaking=false;
    android.content.SharedPreferences prefs;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b); prefs=getSharedPreferences("reader",MODE_PRIVATE); systemTts=new TextToSpeech(this,this);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(24,20,24,20); root.setLayoutDirection(android.view.View.LAYOUT_DIRECTION_RTL); root.setBackgroundColor(0xFFF7F4EE);
        TextView title=new TextView(this); title.setText("کتاب‌خوان فارسی"); title.setTextSize(24); title.setTypeface(null,Typeface.BOLD); title.setGravity(Gravity.CENTER); title.setPadding(0,8,0,18); root.addView(title);
        Button open=new Button(this); open.setText("باز کردن فایل TXT"); root.addView(open);
        textBox=new EditText(this); textBox.setGravity(Gravity.TOP|Gravity.RIGHT); textBox.setTextSize(18); textBox.setHint("متن فارسی را وارد کنید…"); textBox.setMinLines(8); textBox.setMaxLines(16); textBox.setTextDirection(android.view.View.TEXT_DIRECTION_FIRST_STRONG); LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,0,1); ep.setMargins(0,12,0,12); root.addView(textBox,ep);
        textBox.setText(prefs.getString("text",""));
        TextView speedLabel=new TextView(this); speedLabel.setText("سرعت خواندن (صدای داخلی گوشی)"); root.addView(speedLabel);
        speed=new SeekBar(this); speed.setMax(15); speed.setProgress(prefs.getInt("speed",5)); root.addView(speed);
        LinearLayout buttons=new LinearLayout(this); buttons.setOrientation(LinearLayout.HORIZONTAL); buttons.setLayoutDirection(android.view.View.LAYOUT_DIRECTION_LTR);
        play=new Button(this); play.setText("شروع از اول"); stop=new Button(this); stop.setText("توقف"); resume=new Button(this); resume.setText("ادامه"); next=new Button(this); next.setText("بخش بعد"); buttons.addView(play,new LinearLayout.LayoutParams(0,-2,1)); buttons.addView(resume,new LinearLayout.LayoutParams(0,-2,1)); buttons.addView(stop,new LinearLayout.LayoutParams(0,-2,1)); root.addView(buttons); LinearLayout extra=new LinearLayout(this); extra.setOrientation(LinearLayout.HORIZONTAL); extra.setLayoutDirection(android.view.View.LAYOUT_DIRECTION_LTR); extra.addView(next,new LinearLayout.LayoutParams(0,-2,1)); Button voiceSettings=new Button(this); voiceSettings.setText("تنظیم صدای گوشی"); extra.addView(voiceSettings,new LinearLayout.LayoutParams(0,-2,1)); root.addView(extra); voiceSettings.setOnClickListener(v->{try{startActivity(new Intent("android.settings.TTS_SETTINGS"));}catch(Exception e){status.setText("تنظیمات صدای گوشی در دسترس نیست.");}});
        Button clear=new Button(this); clear.setText("پاک کردن متن"); root.addView(clear);
        status=new TextView(this); status.setGravity(Gravity.CENTER); status.setPadding(0,12,0,0); status.setText("متن و سرعت به‌صورت خودکار ذخیره می‌شوند."); root.addView(status); setContentView(root);
        textBox.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){prefs.edit().putString("text",s.toString()).putInt("resume_chunk",0).apply(); activeChunk=0; chunks.clear();} public void afterTextChanged(Editable e){}});
        speed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean u){prefs.edit().putInt("speed",p).apply();}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});
        open.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("text/plain");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_TEXT);});
        play.setOnClickListener(v->speakText()); resume.setOnClickListener(v->resumeText()); next.setOnClickListener(v->nextChunk()); stop.setOnClickListener(v->{if(systemTts!=null)systemTts.stop();speaking=false;prefs.edit().putInt("resume_chunk",activeChunk).apply();status.setText("پخش متوقف شد؛ موقعیت ذخیره شد.");});
        clear.setOnClickListener(v->{if(systemTts!=null)systemTts.stop();textBox.setText("");chunks.clear();activeChunk=0;prefs.edit().putInt("resume_chunk",0).apply();status.setText("متن پاک شد.");});
    }
    @Override public void onInit(int code){ if(code==TextToSpeech.SUCCESS){ttsReady=true; int r=systemTts.setLanguage(new Locale("fa","IR")); if(r==TextToSpeech.LANG_MISSING_DATA||r==TextToSpeech.LANG_NOT_SUPPORTED) status.setText("صدای فارسی در موتور TTS گوشی موجود نیست؛ باید نصب شود."); else status.setText("آماده. صدای فارسی از موتور داخلی گوشی استفاده می‌کند."); systemTts.setOnUtteranceProgressListener(new UtteranceProgressListener(){@Override public void onStart(String id){speaking=true;}@Override public void onDone(String id){if(id.startsWith("chunk_")){try{activeChunk=Integer.parseInt(id.substring(6))+1;}catch(Exception ignored){} prefs.edit().putInt("resume_chunk",activeChunk).apply(); if(activeChunk>=chunks.size()){activeChunk=0;prefs.edit().putInt("resume_chunk",0).apply();speaking=false;runOnUiThread(()->status.setText("خواندن متن تمام شد."));}}}@Override public void onError(String id){speaking=false;runOnUiThread(()->status.setText("خطا در خواندن بخشی از متن."));}}); } else status.setText("موتور گفتار گوشی راه‌اندازی نشد."); }
    private void speakText(){ if(!ttsReady){status.setText("موتور گفتار هنوز آماده نیست.");return;} String txt=textBox.getText().toString().trim(); if(txt.isEmpty()){status.setText("ابتدا متن وارد کنید.");return;} systemTts.stop(); chunks=split(txt); activeChunk=0; prefs.edit().putInt("resume_chunk",0).apply(); enqueueFrom(0); }
    private void resumeText(){ if(!ttsReady){status.setText("موتور گفتار هنوز آماده نیست.");return;} if(chunks.isEmpty())chunks=split(textBox.getText().toString().trim()); if(chunks.isEmpty()){status.setText("ابتدا متن وارد کنید.");return;} activeChunk=prefs.getInt("resume_chunk",activeChunk); if(activeChunk>=chunks.size())activeChunk=0; enqueueFrom(activeChunk); }
    private void nextChunk(){ if(!ttsReady){status.setText("موتور گفتار هنوز آماده نیست.");return;} if(chunks.isEmpty())chunks=split(textBox.getText().toString().trim()); if(chunks.isEmpty()){status.setText("ابتدا متن وارد کنید.");return;} systemTts.stop(); activeChunk=prefs.getInt("resume_chunk",activeChunk); int target=Math.min(activeChunk+1,chunks.size()-1); activeChunk=target; prefs.edit().putInt("resume_chunk",target).apply(); enqueueFrom(target); }
    private void enqueueFrom(int start){systemTts.stop(); systemTts.setSpeechRate(0.65f+speed.getProgress()*0.07f); for(int i=start;i<chunks.size();i++) systemTts.speak(chunks.get(i),i==start?TextToSpeech.QUEUE_FLUSH:TextToSpeech.QUEUE_ADD,null,"chunk_"+i); status.setText("در حال خواندن متن (بخش "+(start+1)+" از "+chunks.size()+")…");}
    private List<String> split(String text){ List<String> out=new ArrayList<>(); String[] sentences=text.split("(?<=[.!؟?؛])\\s+|(?<=،)\\s+"); StringBuilder b=new StringBuilder(); for(String s:sentences){s=s.trim(); if(s.isEmpty())continue; if(b.length()+s.length()>2500){if(b.length()>0)out.add(b.toString());b.setLength(0);} if(b.length()>0)b.append(" ");b.append(s);} if(b.length()>0)out.add(b.toString()); if(out.isEmpty())out.add(text); return out; }
    @Override protected void onActivityResult(int rq,int rc,Intent d){super.onActivityResult(rq,rc,d);if(rq==PICK_TEXT&&rc==RESULT_OK&&d!=null){Uri u=d.getData();try(InputStream in=getContentResolver().openInputStream(u)){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);textBox.setText(new String(out.toByteArray(),StandardCharsets.UTF_8));status.setText("فایل متنی بارگذاری شد و ذخیره شد.");}catch(Exception e){status.setText("خواندن فایل ناموفق بود.");}}}
    @Override public void onDestroy(){if(systemTts!=null){systemTts.stop();systemTts.shutdown();}super.onDestroy();}
}
